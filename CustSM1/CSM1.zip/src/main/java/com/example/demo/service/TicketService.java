package com.example.demo.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.model.Resolve;
import com.example.demo.model.Ticket;
import com.example.demo.repo.EmployeeRepository;
import com.example.demo.repo.ResolveRepository;
import com.example.demo.repo.TicketRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class TicketService {

	@Autowired
	private TicketRepository ticketRepository;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
    private ResolveRepository resolveRepository;
	
	public List<Ticket> showTicket() {
		return ticketRepository.findAll();
	}
	
	public Ticket searchTicketByTicketId(int ticketId) {
		return ticketRepository.findById(ticketId).get();
	}
	
	public List<Ticket> searchTicketByCustomerId(int customerId) {
		return ticketRepository.findTicketByCustomerId(customerId);
	}
	
	public List<Ticket> searchTicketByEmployeeId(int employeeId) {
		return ticketRepository.findTicketByEmployeeId(employeeId);
	}
	
	public void addTicket(Ticket ticket) {
        // Set Raise Date in required format
        ticket.setTicketRaiseDate(LocalDateTime.now());

        // Assign ticket priority based on ticket type
        ticket.setTicketPriority(assignPriority(ticket.getTicketType()));

        // Assign employee in a round-robin fashion
//        ticket.setEmployeeId(assignEmployee(ticket.getTicketType()));

        // Set default ticket status
        ticket.setTicketStatus("Pending");

        ticketRepository.save(ticket);
    }
	
	private String assignPriority(String ticketType) {
        return switch (ticketType.toLowerCase()) {
            case "outage" -> "High";
            case "service", "technical", "complaint" -> "Medium";
            case "billing" -> "Low";
            default -> "Low"; // Default to low priority
        };
    }
	
//	private int assignEmployee(String employeeDept) {
//        List<Employee> employees = employeeRepository.findEmployeesByDomain(employeeDept);
//        if (employees.isEmpty()) {
//            throw new RuntimeException("No employees found for domain: " + employeeDept);
//        }
//
//        // Find the next employee in round-robin
//        int assignedEmployee = employees.get(0);
//        long minCount = ticketRepository.countTicketsByEmployeeAndDomain(assignedEmployee, employeeDept);
//
//        for (int employeeId : employees) {
//            long ticketCount = ticketRepository.countTicketsByEmployeeAndDomain(employeeId, employeeDept);
//            if (ticketCount < minCount) {
//                minCount = ticketCount;
//                assignedEmployee = employeeId;
//            }
//        }
//        return assignedEmployee;
//    }
	
	
	public List<Ticket> searchTicketByStatus(String ticketStatus) {
        List<Ticket> tickets = ticketRepository.findUnresolvedTicketsByStatus(ticketStatus);
        
        if ("CLOSED".equalsIgnoreCase(ticketStatus)) {
            for (Ticket ticket : tickets) {
                if (!resolveRepository.existsByTicketId(ticket.getTicketId())) {
                    Resolve resolve = new Resolve();
                    resolve.setTicketId(ticket.getTicketId());
                    resolve.setEmployeeId(ticket.getEmployeeId());
                    
                    LocalDateTime resolveDate = LocalDateTime.now();
                    LocalDateTime raiseDate = ticket.getTicketRaiseDate();
                    
                    // Calculate days between raise date and resolve date
                    int turnAroundDays = (int) ChronoUnit.DAYS.between(raiseDate, resolveDate);
                    
                    resolve.setResolveDate(resolveDate);
                    resolve.setEmployeeDescription("Ticket closed automatically");
                    resolve.setTurnAroundTime(turnAroundDays);
                    resolve.setDelayReason(turnAroundDays > 7 ? "Exceeded SLA" : "N/A");
                    
                    resolveRepository.save(resolve);
                }
            }
        }
        return tickets;
    }
	
	public void updateTicket(Ticket ticket) {
		ticketRepository.save(ticket);
	}
	
	public void deleteTicketByTicketId(int ticId) {
		ticketRepository.deleteById(ticId);
	}
	
}
