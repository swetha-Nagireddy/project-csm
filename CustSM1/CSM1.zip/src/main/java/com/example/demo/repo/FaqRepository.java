package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Faq;

import java.util.Optional;

public interface FaqRepository extends JpaRepository<Faq, Long> {
	
	Optional<Faq> findById(Long faqId);

}
