package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Faq;
import com.example.demo.service.ChatbotService;


@RestController
@RequestMapping("/chatbot")

class ChatbotController {
    @Autowired
    private ChatbotService chatbotService;
    
    @GetMapping("/ticketstatus/{customerId}")
    public String getTicketStatus(@PathVariable int customerId) {
        return chatbotService.getTicketStatus(customerId);
    }
    
    @GetMapping("/faqs")
    public List<Faq> getFaqs() {
        return chatbotService.getAllFaqs();
    }
}