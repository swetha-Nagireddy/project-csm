package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private BCryptPasswordEncoder bencoder;
	
	public List<Customer> showCustomer(){
		return customerRepository.findAll();
	}
  
	public Customer searchById(int id) {
		return customerRepository.findById(id).get();
	}
	
	public Customer searchByUserName(String userName) {
		return customerRepository.findByCustomerUsername(userName);
	}
	
	public String login(String customerUserName, String customerPassword) {
		Customer customer = customerRepository.findByCustomerUsername(customerUserName);
        if (customer != null) {
            // Compare the provided password with the stored password using bcrypt
            if (bencoder.matches(customerPassword, customer.getCustomerPassword())) {
                return "Login successful!";
            } else {
                return "Invalid credentials!";
            }
        }
        return "Invalid credentials!";
	}
	
	public Customer searchByPhNo(String customerPhNo) {
		return customerRepository.findByCustomerPhNo(customerPhNo);
	}
	
	public String addCustomer(Customer customer) {
		 customer.setCustomerPassword(bencoder.encode(customer.getCustomerPassword()));
		 customerRepository.save(customer);
		 return "User Added Successfully";
	}
	
	public void updateCustomer(Customer customer) {
		customerRepository.save(customer);
	}
	
	public void deleteCustomer(int customerId) {
		customerRepository.deleteById(customerId);
	}
}
