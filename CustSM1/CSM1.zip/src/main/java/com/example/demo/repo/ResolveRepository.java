package com.example.demo.repo;
 
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
 
import com.example.demo.model.Resolve;
import com.example.demo.model.Ticket;
 
public interface ResolveRepository extends JpaRepository<Resolve, Integer>{
	
	Resolve findByTicketId(int ticketId);
	List<Resolve> findByEmployeeId(int employeeId);
	boolean existsByTicketId(int ticketId);
}