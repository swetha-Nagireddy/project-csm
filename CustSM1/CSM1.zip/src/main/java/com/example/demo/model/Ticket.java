package com.example.demo.model;

import java.sql.Date;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="TICKET")
public class Ticket {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="TICKET_ID")
	private int ticketId;
	
	@Column(name="CUSTOMER_ID")
	private int customerId;
	
	@Column(name="EMPLOYEE_ID")
	private int employeeId;
	
	@Column(name="TICKET_TYPE")
	private String ticketType;
	
	@Column(name="TICKET_DESCRIPTION")
	private String ticketDescription;
	
	@Column(name="TICKET_RAISEDATE")
	private LocalDateTime ticketRaiseDate;
	
	@Column(name="TICKET_STATUS")
	private String ticketStatus;
	
	@Column(name="TICKET_PRIORITY")
	private String ticketPriority;
	
	public String getTicketStatus() {
        return ticketStatus;
    }
}
