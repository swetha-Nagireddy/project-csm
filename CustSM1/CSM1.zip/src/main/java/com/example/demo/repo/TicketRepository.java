package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Ticket;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Integer>{

	List<Ticket> findTicketByCustomerId(int customerId);
	List<Ticket> findTicketByEmployeeId(int employeeId);
	List<Ticket> findByTicketStatus(String ticketStatus);
	
    @Query("SELECT t FROM Ticket t WHERE t.ticketStatus = ?1 AND NOT EXISTS (SELECT r FROM Resolve r WHERE r.ticketId = t.ticketId)")
    List<Ticket> findUnresolvedTicketsByStatus(String ticketStatus);

	@Query("SELECT COUNT(t) FROM Ticket t WHERE t.employeeId = ?1 AND t.ticketType = ?2")
    long countTicketsByEmployeeAndDomain(int employeeId, String ticketType);
	
	@Query("SELECT e.employeeId FROM Employee e WHERE e.employeeDept = ?1 ORDER BY e.employeeId ASC")
    List<Integer> findEmployeesByDomain(String domain);
}
