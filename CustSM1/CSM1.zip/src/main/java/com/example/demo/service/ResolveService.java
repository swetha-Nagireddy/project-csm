package com.example.demo.service;
 
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.model.Resolve;
import com.example.demo.repo.ResolveRepository;
 
import jakarta.transaction.Transactional;
 
@Service
@Transactional
public class ResolveService {
	
	@Autowired
	private ResolveRepository resolveRepository;

	public List<Resolve> showResolve(){
		return resolveRepository.findAll();
	}
	
	public Resolve searchResolveByTicketId(int ticketId) {
	    Resolve resolve = resolveRepository.findByTicketId(ticketId);
	    if (resolve == null) {
	        throw new RuntimeException("Resolve not found for ticket ID: " + ticketId);
	    }
	    return resolve;
	}

	
	public List<Resolve> searchResolveByEmployeeId(int employeeId) {
        return resolveRepository.findByEmployeeId(employeeId);
    }
	
	public void addResolve(Resolve resolve) {
	    if (!resolveRepository.existsByTicketId(resolve.getTicketId())) {
	        resolveRepository.save(resolve);
	    } else {
	        throw new RuntimeException("Resolve already exists for this Ticket ID");
	    }
	}

	
	public void updateResolve(Resolve resolve) {
		resolveRepository.save(resolve);
	}
	
	public void deleteResolveByTicketId(int ticketId) {
	    Resolve resolve = resolveRepository.findByTicketId(ticketId);
	    if (resolve != null) {
	        resolveRepository.delete(resolve);
	    }
	}


}