package com.example.demo.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Ticket;
import com.example.demo.service.TicketService;

@RestController
@RequestMapping(value="/ticket")
public class TicketController {

	@Autowired
	private TicketService ticketService;
	
	@GetMapping(value = "/showTicket")
	public List<Ticket> showTicket(){
		return ticketService.showTicket();
	}
	
	@GetMapping(value="/searchTicketByTicketId/{id}")
	public ResponseEntity<Ticket> get(@PathVariable int id) {
		try {
			Ticket ticket = ticketService.searchTicketByTicketId(id);
			return new ResponseEntity<Ticket>(ticket, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<Ticket>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping(value="/searchTicketByCustomerId/{customerId}")
	public ResponseEntity<List<Ticket>> searchTicketByCustomerId(@PathVariable int customerId) {
		List<Ticket> ticketList = ticketService.searchTicketByCustomerId(customerId);
		if(ticketList.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(ticketList, HttpStatus.OK);
	}
	
	@GetMapping(value="/searchTicketByEmployeeId/{employeeId}")
	public ResponseEntity<List<Ticket>> searchTicketByEmpId(@PathVariable int employeeId) {
		List<Ticket> ticketList = ticketService.searchTicketByEmployeeId(employeeId);
		if(ticketList.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(ticketList, HttpStatus.OK);
	}
	
	@GetMapping("/searchTicketByStatus/{status}")
    public ResponseEntity<List<Ticket>> searchTicketByStatus(@PathVariable String status) {
        List<Ticket> tickets = ticketService.searchTicketByStatus(status);
        return tickets.isEmpty() ? 
            new ResponseEntity<>(HttpStatus.NOT_FOUND) :
            new ResponseEntity<>(tickets, HttpStatus.OK);
    }
	
	@PostMapping(value="/addTicket")
		public void addTicket(@RequestBody Ticket ticket) {
			ticketService.addTicket(ticket);
	}
	
	@PutMapping(value="/updateTicket")
	public void updateTicket(@RequestBody Ticket ticket) {
		ticketService.updateTicket(ticket);
	}
	
	@DeleteMapping(value="/deleteTicketById/{ticketId}")
	public void deleteTicket(@PathVariable int ticketId) {
		ticketService.deleteTicketByTicketId(ticketId);
	}
	
}
